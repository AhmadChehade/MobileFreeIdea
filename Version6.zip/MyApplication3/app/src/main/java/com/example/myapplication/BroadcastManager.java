package com.example.myapplication;

import android.app.Activity;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static android.provider.Settings.System.getString;
import static androidx.core.content.ContextCompat.getSystemService;

public class BroadcastManager extends BroadcastReceiver {
    public static final String EXTRA_MESSAGE = "message";
    public static final String CHANNEL_ID = "CHANNEL";
    public static final String textTitle = "Med R";
    public static final String textContent = "It is time to take: ";
    int notificationId = 2020;



    @Override
    public void onReceive(Context context, Intent intent) {
        String upcoming = intent.getStringExtra("key");
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.advil)
                .setContentTitle(textTitle)
                .setContentText(textContent + upcoming)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

        notificationManager.notify(notificationId, builder.build());
    }


//    public BroadcastManager() {
//        super(CHANNEL_ID);
//    }

//    private void showText(final String text) {
//        Intent intent = new Intent(this, MainActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
//
//
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
//                .setSmallIcon(R.drawable.advil)
//                .setContentTitle(textTitle)
//                .setContentText(textContent)
//                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//                .setContentIntent(pendingIntent)
//                .setAutoCancel(true);
//        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
//        notificationManager.notify(notificationId, builder.build());
//    }
//
//
//    private void createNotificationChannel() {
//        // Create the NotificationChannel, but only on API 26+ because
//        // the NotificationChannel class is new and not in the support library
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            CharSequence name = getString(R.string.channel_name);
//            String description = getString(R.string.channel_description);
//            int importance = NotificationManager.IMPORTANCE_DEFAULT;
//            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
//            channel.setDescription(description);
//            // Register the channel with the system; you can't change the importance
//            // or other notification behaviors after this
//            NotificationManager notificationManager = getSystemService(NotificationManager.class);
//            notificationManager.createNotificationChannel(channel);
//        }
//    }
//
//
//    @Override
//    protected void onHandleIntent(@Nullable Intent intent) {
//        String display = intent.getStringExtra(EXTRA_MESSAGE);
//
//        synchronized (this){
//            try {
//                wait(1);
//            } catch (InterruptedException e){
//                e.printStackTrace();
//            }
//        }
//
//        createNotificationChannel();
//        showText(display);
//    }
//
//    @RequiresApi(api = Build.VERSION_CODES.O)
//    @Override
//    public void onReceive(Context context, Intent intent) {
//        try {
//            String yourDate = "27-11-2020";
//            String yourHour = "22:26";
//            LocalDateTime myDate = LocalDateTime.now();
//            DateTimeFormatter date = DateTimeFormatter.ofPattern("dd-MM-yyyy");
//            String formattedDate = myDate.format(date);
//            DateTimeFormatter time = DateTimeFormatter.ofPattern("HH:mm");
//            String formattedTime = myDate.format(time);
//
////            Date d = new Date();
////            SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
////            SimpleDateFormat hour = new SimpleDateFormat("HH:mm");
//            if (formattedDate.equals(yourDate) && formattedTime.equals(yourHour)) {
//                Intent it = new Intent(context, MainActivity.class);
//                createNotification(context, it, "new message", "body!", "this is a message");
//            }
//        } catch (Exception e) {
//            Log.i("date", "error == " + e.getMessage());
//        }
//    }
//
//
//    public void createNotification(Context context, Intent intent, CharSequence ticker, CharSequence title, CharSequence descricao) {
//        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
//        PendingIntent p = PendingIntent.getActivity(context, 0, intent, 0);
//
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
//        builder.setTicker(ticker);
//        builder.setContentTitle(title);
//        builder.setContentText(descricao);
//        builder.setSmallIcon(R.drawable.advil);
//        builder.setContentIntent(p);
//
//        Notification n = builder.build();
//        //create the notification
//        n.vibrate = new long[]{150, 300, 150, 400};
//        n.flags = Notification.FLAG_AUTO_CANCEL;
//        nm.notify(R.drawable.advil, n);
//        //create a vibration
//        try {
//
//            Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//            Ringtone toque = RingtoneManager.getRingtone(context, som);
//            toque.play();
//        } catch (Exception e) {
//        }
//    }
}
