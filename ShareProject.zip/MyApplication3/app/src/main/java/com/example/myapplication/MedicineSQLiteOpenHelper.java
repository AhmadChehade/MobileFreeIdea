package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MedicineSQLiteOpenHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "Database_1.db";
    private static final int DB_VERSION = 4;

    public MedicineSQLiteOpenHelper (Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS MEDICINE (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," + "" +
                "NAME TEXT," +
                "DESCRIPTION_ENGLISH TEXT," +
                "DESCRIPTION_FRENCH TEXT," +
                "IMAGE_RESOURCE_ID INTEGER)");

        db.execSQL("CREATE TABLE IF NOT EXISTS SELECTED_MEDICINE (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," + "" +
                "NAME TEXT," +
                "REMINDER_DATE TEXT)");


        try{
            Cursor mCursor = db.rawQuery("SELECT * FROM " + "MEDICINE", null);
            if (!mCursor.moveToFirst()) {
                InitializeDatabase(db);
            }

            mCursor.close();
        }
        catch (Exception e){

        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public static void InitializeDatabase(SQLiteDatabase db) {
        insertMedicine(db, "Viagra", "sex", "sexes", R.drawable.untitled);
    }

    public static void insertMedicine(SQLiteDatabase db, String name, String description_english, String description_french, int imageID){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME", name);
        contentValues.put("DESCRIPTION_ENGLISH", description_english);
        contentValues.put("DESCRIPTION_FRENCH", description_french);
        contentValues.put("IMAGE_RESOURCE_ID", imageID);
        db.insert("MEDICINE", null, contentValues);
    }

    public static void insertSelectedMedicine(SQLiteDatabase db, String name, String date){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME", name);
        contentValues.put("REMINDER_DATE", date);
        db.insert("SELECTED_MEDICINE", null, contentValues);
    }
}

