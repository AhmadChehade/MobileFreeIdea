package com.example.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MedicineDetailsFragment extends Fragment {
    private long medicineID;
    String setDate = "";
    String setTime = "";

    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        if (view != null) {
            //ImageView imageViewItemImage = view.findViewById(R.id.imageViewItemImage);
            //TextView textViewName = view.findViewById(R.id.textViewName);
            //TextView textViewDescription = view.findViewById(R.id.textViewDescription);

            ImageView imageView = view.findViewById(R.id.imageViewItemImage);
            TextView textViewName = view.findViewById(R.id.textViewName);
            TextView textViewDescription = view.findViewById(R.id.textViewDescription);
            TextView textViewWarning = view.findViewById(R.id.warning);

            MedicineSQLiteOpenHelper medicineSQLiteOpenHelper = new MedicineSQLiteOpenHelper(this.getContext());
            SQLiteDatabase db = medicineSQLiteOpenHelper.getReadableDatabase();
//            Cursor cursor = db.query(
//                    "MEDICINE",
//                    new String[]{"_id", "NAME"},
//                    "_id = ?",
//                    new String[]{String.valueOf(medicineID)},
//                    null,
//                    null,
//                    null);
            Cursor cursor = db.query("MEDICINE",
                    new String[]{"NAME", "DESCRIPTION_ENGLISH", "WARNING_ENGLISH", "IMAGE_RESOURCE_ID"},
                    "_id=?", new String[]{String.valueOf(medicineID+1)},
                    null, null, null);
            if (cursor.moveToFirst()) {
                String nameText = cursor.getString(0);
                String descText = cursor.getString(1);
                String warningText = cursor.getString(2);
                int imageId = cursor.getInt(3);

                textViewName.setText(nameText);
                textViewDescription.setText(descText);
                textViewWarning.setText(warningText);
                imageView.setImageResource(imageId);
            }
            cursor.close();
            db.close();
        }

//        CODE HERE


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (savedInstanceState != null) {
            medicineID = savedInstanceState.getLong("medicine_id");
        }
        return inflater.inflate(R.layout.fragment_medicine_details, container, false);
    }

    public void onSaveInstanceState(Bundle outState) {
        outState.putLong("medicine_id", medicineID);
    }

    public void setMedicineID(long medicineID) {
        this.medicineID = medicineID;
    }

    public void showTimePickerDialog(View v) {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getFragmentManager(), "timePicker");
    }
    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getFragmentManager(), "datePicker");
    }

    public void setDateValue(String dateFormatted){
        View v = getView();
        setDate = dateFormatted;
        TextView textView = v.findViewById(R.id.dateText);
        textView.setText(setDate);
    }
    public void setTimeValue(String timeFormatted){
        View v = getView();
        setTime = timeFormatted;
        TextView textView = v.findViewById(R.id.timeText);
        textView.setText(setTime);
    }
}