package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayActivity extends AppCompatActivity {

    public static final String ITEM_NUMBER = "item_number";
    String setDate = "";
    String setTime = "";
//    String deviceLanguage = getString(R.string.language_option);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        Intent intent = getIntent();
        int itemNum = intent.getIntExtra(ITEM_NUMBER, 0);

        try {
            ImageView imageView = findViewById(R.id.imageViewItemImage);
            TextView textViewName = findViewById(R.id.textViewName);
            TextView textViewDescription = findViewById(R.id.textViewDescription);
            TextView textViewWarning = findViewById(R.id.warning);

            SQLiteOpenHelper sqLiteOpenHelper = new MedicineSQLiteOpenHelper(this);
            SQLiteDatabase db = sqLiteOpenHelper.getReadableDatabase();
            Cursor cursor = db.query("MEDICINE",
                    new String[]{"NAME", "DESCRIPTION_ENGLISH","WARNING_ENGLISH", "IMAGE_RESOURCE_ID"},
                    "_id=?", new String[]{Integer.toString(itemNum)},
                    null, null, null );
            if(cursor.moveToFirst()) {
                String nameText = cursor.getString(0);
                String descText = cursor.getString(1);
                String warningText = cursor.getString(2);
                int imageId = cursor.getInt(3);

                textViewName.setText(nameText);
                textViewDescription.setText(descText);
                textViewWarning.setText(warningText);
                imageView.setImageResource(imageId);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }

    }

    public void showTimePickerDialog(View v) {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getSupportFragmentManager(), "timePicker");
    }
    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void setDateValue(String dateFormatted){
        setDate = dateFormatted;
        TextView textView = findViewById(R.id.dateText);
        textView.setText(setDate);
    }
    public void setTimeValue(String timeFormatted){
        setTime = timeFormatted;
        TextView textView = findViewById(R.id.timeText);
        textView.setText(setTime);
    }
}