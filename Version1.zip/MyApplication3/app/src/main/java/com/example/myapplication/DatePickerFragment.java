package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TextView;

import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class DatePickerFragment extends DialogFragment
        implements DatePickerDialog.OnDateSetListener {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onDateSet(DatePicker view, int year, int month, int day) {
        // Do something with the date chosen by the user
        String formattedDate;
        int months = month + 1;
        if (months < 10 && day < 10) {
            formattedDate = "0" + day + "-" + "0" + months + "-" + year;
        } else if (months < 10) {
            formattedDate = day + "-" + "0" + months + "-" + year;
        } else if (day < 10) {
            formattedDate = "0" + day + "-" + months + "-" + year;
        } else {
            formattedDate = day + "-" + months + "-" + year;
        }

        ((DisplayActivity) getActivity()).setDateValue(formattedDate);

    }
}
