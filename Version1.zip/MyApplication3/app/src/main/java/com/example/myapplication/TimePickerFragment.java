package com.example.myapplication;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;

import android.text.format.DateFormat;

import android.widget.TimePicker;

import java.util.Calendar;


public class TimePickerFragment extends DialogFragment
        implements TimePickerDialog.OnTimeSetListener  {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        // Create a new instance of TimePickerDialog and return it
        return new TimePickerDialog(getActivity(), this, hour, minute,
                DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        // Do something with the time chosen by the user
        String formattedTime;
        if (hourOfDay < 10 && minute < 10) {
            formattedTime = "0"+ hourOfDay+":0"+minute;
        } else if (hourOfDay < 10) {
            formattedTime = "0"+hourOfDay+":"+minute;
        } else if (minute< 10) {
            formattedTime = hourOfDay+":0"+minute;
        } else {
            formattedTime = hourOfDay+":"+minute;
        }

        ((DisplayActivity) getActivity()).setTimeValue(formattedTime);
    }
}