package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class MedicineSQLiteOpenHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "Medicine.db";
    private static final int DB_VERSION = 1;

    public MedicineSQLiteOpenHelper (Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS MEDICINE (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," + "" +
                "NAME TEXT," +
                "DESCRIPTION_ENGLISH TEXT," +
                "WARNING_ENGLISH TEXT, "+
                "DESCRIPTION_FRENCH TEXT," +
                "WARNING_FRENCH TEXT,"+
                "IMAGE_RESOURCE_ID INTEGER)");

        db.execSQL("CREATE TABLE IF NOT EXISTS SELECTED_MEDICINE (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," + "" +
                "NAME TEXT," +
                "REMINDER_DATE TEXT,"+
                "REMINDER_TIME TEXT)");


        try{
            Cursor mCursor = db.rawQuery("SELECT * FROM " + "MEDICINE", null);
            if (!mCursor.moveToFirst()) {
                InitializeDatabase(db);
            }

            mCursor.close();
        }
        catch (Exception e){
                System.out.println(e.toString());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public static void InitializeDatabase(SQLiteDatabase db) {
        insertMedicine(db, "Advil", "Advil is a nonsteroidal anti-inflammatory drug (NSAID). Ibuprofen works by reducing hormones that cause inflammation and pain in the body. Advil is used to reduce fever and treat pain or inflammation caused by many conditions such as headache, toothache, back pain, arthritis, menstrual cramps, or minor injury.\n" +
                "Dosage: 3200 mg per day (4 maximum doses).", "Warning: Long term or high doses can increase risk of fatal heart attack.", "Advil est un anti-inflammatoire non stéroïdien (AINS). L'ibuprofène agit en réduisant les hormones qui causent l'inflammation et la douleur dans le corps. Advil est utilisé pour réduire la fièvre et traiter la douleur ou l'inflammation causées par de nombreuses conditions telles que maux de tête, maux de dents, maux de dos, arthrite, crampes menstruelles ou blessures mineures.\n" +
                "Dosage: 3200 mg par jour (4 doses maximales).","Avertissement: des doses à long terme ou élevées peuvent augmenter le risque de crise cardiaque mortelle.",R.drawable.advil);
        insertMedicine(db, "Augmentin", "Augmentin is prescription antibiotic used to treat many different infections caused by bacteria, such as , pneumonia, ear infections, bronchitis, urinary tract infections, and infections of the skin.\n" +
                "Dosage: one 500-mg tablet of AUGMENTIN every 12 hours or one 250-mg tablet of AUGMENTIN every 8 hours.", "Warning: Two 250-mg tablets of AUGMENTIN should not be substituted for one 500-mg tablet of AUGMENTIN.","Augmentin est un antibiotique sur ordonnance utilisé pour traiter de nombreuses infections causées par des bactéries, telles que la pneumonie, les otites, la bronchite, les infections des voies urinaires et les infections de la peau.\n" +
                "Posologie: un comprimé de 500 mg d'AUGMENTIN toutes les 12 heures ou un comprimé de 250 mg d'AUGMENTIN toutes les 8 heures.","Avertissement: Deux comprimés d'AUGMENTIN à 250 mg ne doivent pas être remplacés par un comprimé d'AUGMENTIN à 500 mg.", R.drawable.augmentin);
        insertMedicine(db, "Cal-C-Vita", "Cal-C-Vita is a calcium preparation containing Calcium and Vitamins C, D3 and B6. Vitamins D3 and B6 enable the absorption of calcium into bone, while vitamins C and B6 contribute to bone formation and maturation.\n" +
                "Dosage: One tablet daily.", "Warning: High doses of vitamin D may lead to toxic reactions.","Cal-C-Vita est une préparation de calcium contenant du calcium et des vitamines C, D3 et B6. Les vitamines D3 et B6 permettent l'absorption du calcium dans les os, tandis que les vitamines C et B6 contribuent à la formation et à la maturation des os.\n" +
                "Dosage: un comprimé par jour.","Attention: des doses élevées de vitamine D peuvent entraîner des réactions toxiques.", R.drawable.calcvita);
        insertMedicine(db, "Imodium", "Imodium is an antidiarrheal used to treat diarrhea. Imodium is also used to reduce the amount of stool in people who have an ileostomy. Imodium is available in generic form and over-the-counter.\n" +
                "Dosage: 4mg (two capsules) followed by 2 mg (one capsule) after each unformed stool for Adults.", "Warning: Daily dose should not exceed 16mg.",
                "Imodium est un antidiarrhéique utilisé pour traiter la diarrhée. Imodium est également utilisé pour réduire la quantité de selles chez les personnes qui ont une iléostomie. Imodium est disponible sous forme générique et en vente libre.\n" +
                "Dosage: 4 mg (deux capsules) suivis de 2 mg (une capsule) après chaque selle non formée pour les adultes.","\n" +
                "Attention: la dose quotidienne ne doit pas dépasser 16 mg.", R.drawable.imodium);
        insertMedicine(db, "Insulin", "Insulin is a protein hormone that is used as a medication to treat high blood glucose. This includes in diabetes mellitus type 1, diabetes mellitus type 2, gestational diabetes, and complications of diabetes \n" +
                "Dosage: Is only prescribed by Doctor and varies between one individual and the other.", "Warning: Hypoglycemia may occur and is the most common side effect of insulin treatment.","L'insuline est une hormone protéique utilisée comme médicament pour traiter l'hyperglycémie. Cela comprend le diabète sucré de type 1, le diabète sucré de type 2, le diabète gestationnel et les complications du diabète\n" +
                "Dosage: n'est prescrit que par le médecin et varie d'un individu à l'autre.","Avertissement: une hypoglycémie peut survenir et est l'effet secondaire le plus courant du traitement à l'insuline.", R.drawable.insulin);
        insertMedicine(db, "Panadol Advance", "Panadol Advance is an advanced formulation of paracetamol that contains Optizorb. \n" +
                "Panadol Advance starts to release its medicine in as little as 5 minutes, is gentle on the stomach when used as directed, and still has the safety profile you trust from Panadol. \n" +
                "Dosage: Maximum 2 Tablets per 4 Hours.", "Warnings: Do not exceed more than 4 Tablets in 24 hours -Do not give Panadol Advanced to children for more than 3 days without consulting a Doctor.","Panadol Advance est une formulation avancée de paracétamol qui contient Optizorb.\n" +
                "Panadol Advance commence à libérer son médicament en aussi peu que 5 minutes, est doux pour l'estomac lorsqu'il est utilisé selon les instructions et possède toujours le profil de sécurité auquel vous faites confiance de Panadol.\n" +
                "Dosage: maximum 2 comprimés par 4 heures.\n","Attention: Ne pas dépasser plus de 4 comprimés par 24 heures -Ne pas donner Panadol Advanced aux enfants pendant plus de 3 jours sans consulter un médecin.", R.drawable.panadol_advance);
        insertMedicine(db, "Panadol Extra", "Panadol Extra is a formulation of paracetamol that contains specially formulated ingredients to provide additional pain relief. \n" +
                "Panadol Extra is extra effective against pain, it does not irritate the stomach and is gentle on you.\n" +
                "Dosage: Maximum 2 Tablets per 4 Hours.", "Warning: Do not exceed more than 8 Tablets in 24 hours", "Panadol Extra est une formulation de paracétamol qui contient des ingrédients spécialement formulés pour fournir un soulagement supplémentaire de la douleur.\n" +
                "Panadol Extra est très efficace contre la douleur, il n'irrite pas l'estomac et est doux pour vous.\n" +
                "Dosage: maximum 2 comprimés par 4 heures.","Attention: ne pas dépasser plus de 8 comprimés en 24 heures",R.drawable.panadol_extra);
        insertMedicine(db, "Pencillin", "Penicillin V is used to treat certain infections caused by bacteria such as pneumonia and other respiratory tract infections, scarlet fever, and ear, skin, gum, mouth, and throat infections.\n" +
                "Dosage: Is only prescribed by Doctor and varies between one individual and the other.", "Warning: Penicillin V can cause a severe allergic reaction.", "La pénicilline V est utilisée pour traiter certaines infections causées par des bactéries telles que la pneumonie et d'autres infections des voies respiratoires, la scarlatine et les infections des oreilles, de la peau, des gencives, de la bouche et de la gorge.\n" +
                "Dosage: n'est prescrit que par le médecin et varie d'un individu à l'autre.","Avertissement: la pénicilline V peut provoquer une réaction allergique sévère.",R.drawable.pencillin);
        insertMedicine(db, "Profinal", "Profinal is a nonsteroidal anti-inflammatory drug (NSAID) used to treat mild to moderate pain, and helps to relieve symptoms of arthritis\n" +
                "Dosage: 400 mg.", "Warning: some serious side effects that can occur during treatment with this medicine may include swelling of the face, fingers, feet, and/or lower legs; severe stomach pain. ",
                "Profinal est un anti-inflammatoire non stéroïdien (AINS) utilisé pour traiter la douleur légère à modérée et aide à soulager les symptômes de l'arthrite\n" +
                "Dosage: 400 mg.","Avertissement: certains effets indésirables graves pouvant survenir pendant le traitement par ce médicament peuvent inclure un gonflement du visage, des doigts, des pieds et / ou du bas des jambes; douleur à l'estomac sévère.", R.drawable.profinal);
        insertMedicine(db, "Vitamin D", "Vitamin D promotes calcium absorption in the gut and maintains adequate serum calcium and phosphate concentrations to enable normal bone mineralization and to prevent hypocalcemic tetany\n" +
                "Dosage: recommended daily allowances for vitamin D are 600 IU (15 mcg) daily.", "Warning: Doses reaching 1000mg to 2500mg cause toxicity in humans.","La vitamine D favorise l'absorption du calcium dans l'intestin et maintient des concentrations sériques de calcium et de phosphate adéquates pour permettre une minéralisation osseuse normale et prévenir la tétanie hypocalcémique\n" +
                "Dosage: les apports journaliers recommandés pour la vitamine D sont de 600 UI (15 mcg) par jour.","Avertissement: des doses atteignant 1000 mg à 2500 mg provoquent une toxicité chez l'homme.", R.drawable.vitamind);
    }

    public static void insertMedicine(SQLiteDatabase db, String name, String description_english, String warning_english, String description_french, String warning_french, int imageID){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME", name);
        contentValues.put("DESCRIPTION_ENGLISH", description_english);
        contentValues.put("WARNING_ENGLISH", warning_english);
        contentValues.put("DESCRIPTION_FRENCH", description_french);
        contentValues.put("WARNING_FRENCH", warning_french);
        contentValues.put("IMAGE_RESOURCE_ID", imageID);
        db.insert("MEDICINE", null, contentValues);
    }

    public static void insertSelectedMedicine(SQLiteDatabase db, String name, String date, String time){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME", name);
        contentValues.put("REMINDER_DATE", date);
        contentValues.put("REMINDER_TIME", time);
        db.insert("SELECTED_MEDICINE", null, contentValues);
    }
}

