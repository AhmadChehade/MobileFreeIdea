package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MedicineActivity extends AppCompatActivity implements ListFragment.MedicineListListener {


    SQLiteOpenHelper sqLiteOpenHelper;
    SQLiteDatabase db;

//    String deviceLanguage = getString(R.string.language_option);


   // @Override
    /*protected void onListItemClick(ListView l, View v, int position, long id) {
//        super.onListItemClick(l, v, position, id);
        Intent intent = new Intent(this, DisplayActivity.class);
        intent.putExtra(DisplayActivity.ITEM_NUMBER, (int) id);
        startActivity(intent);
    }*/

    @Override
    public void itemClicked(long id) {
        View fragContainer = findViewById(R.id.frag_container);
        if(fragContainer != null){
            MedicineDetailsFragment medicineDetailsFragment = new MedicineDetailsFragment();
            medicineDetailsFragment.setMedicineID(id);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frag_container,medicineDetailsFragment);
            ft.addToBackStack(null);
            ft.commit();
        } else {
            Intent intent = new Intent(this, DisplayActivity.class);
            intent.putExtra(DisplayActivity.EXTRA_MEDICINE_ID,id);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine);

//        sqLiteOpenHelper = new MedicineSQLiteOpenHelper(this);
//
//        try {
//            db = sqLiteOpenHelper.getReadableDatabase();
//
//            Cursor cursor = db.query(
//                    "MEDICINE",
//                    new String[]{"_id", "NAME"},
//                    null,
//                    null,
//                    null,
//                    null,
//                    null);
//            CursorAdapter cursorAdapter = new SimpleCursorAdapter(this,
//                    android.R.layout.simple_list_item_1,
//                    cursor,
//                    new String[]{"NAME"},
//                    new int[]{android.R.id.text1},
//                    0);
//            ListView listView = getListView();
//            listView.setAdapter(cursorAdapter);
//        } catch (Exception e) {
//            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
//        }

    }
}