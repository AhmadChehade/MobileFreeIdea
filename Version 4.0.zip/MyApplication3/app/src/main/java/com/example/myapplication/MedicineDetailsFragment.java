package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;


public class MedicineDetailsFragment extends Fragment {
    private long medicineID;
    Button dateOfBirthET;
    Button timeOfBirthET;
    String selectedTime;
    String selectedDate;
    TextView dateTextField;
    TextView timeTextField;
    String nameText;
    SQLiteDatabase db;
    MedicineSQLiteOpenHelper medicineSQLiteOpenHelper;


    public static final int REQUEST_CODE = 11;
    public static final int REQUEST_CODE1 = 12;

    private OnFragmentInteractionListener mListener;

    public MedicineDetailsFragment() {
        // Required empty public constructor
    }

    public static MedicineDetailsFragment newInstance() {
        MedicineDetailsFragment fragment = new MedicineDetailsFragment();
        return fragment;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }





    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        if (view != null) {
            //ImageView imageViewItemImage = view.findViewById(R.id.imageViewItemImage);
            //TextView textViewName = view.findViewById(R.id.textViewName);
            //TextView textViewDescription = view.findViewById(R.id.textViewDescription);

            ImageView imageView = view.findViewById(R.id.imageViewItemImage);
            TextView textViewName = view.findViewById(R.id.textViewName);
            TextView textViewDescription = view.findViewById(R.id.textViewDescription);
            TextView textViewWarning = view.findViewById(R.id.warning);

            medicineSQLiteOpenHelper = new MedicineSQLiteOpenHelper(this.getContext());
            db = medicineSQLiteOpenHelper.getReadableDatabase();

            String description_choice = getString(R.string.description);
            String warning_choice = getString(R.string.warning);

//            Cursor cursor = db.query(
//                    "MEDICINE",
//                    new String[]{"_id", "NAME"},
//                    "_id = ?",
//                    new String[]{String.valueOf(medicineID)},
//                    null,
//                    null,
//                    null);
            Cursor cursor = db.query("MEDICINE",
                    new String[]{"NAME", description_choice, warning_choice, "IMAGE_RESOURCE_ID"},
                    "_id=?", new String[]{String.valueOf(medicineID+1)},
                    null, null, null);
            if (cursor.moveToFirst()) {
                nameText = cursor.getString(0);
                String descText = cursor.getString(1);
                String warningText = cursor.getString(2);
                int imageId = cursor.getInt(3);

                textViewName.setText(nameText);
                textViewDescription.setText(descText);
                textViewWarning.setText(warningText);
                imageView.setImageResource(imageId);
            }
            cursor.close();
            db.close();
        }

//        CODE HERE


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_medicine_details, container, false);
        // Inflate the layout for this fragment
        if (savedInstanceState != null) {
            medicineID = savedInstanceState.getLong("medicine_id");
        }
        dateTextField = view.findViewById(R.id.dateTextField);
        dateOfBirthET = view.findViewById(R.id.dateOfBirthET);
        timeOfBirthET = view.findViewById(R.id.timeOfBirthET);
        timeTextField = view.findViewById(R.id.timeTextField);


        // get fragment manager so we can launch from fragment
        final FragmentManager fm = ((AppCompatActivity)getActivity()).getSupportFragmentManager();

        // Using an onclick listener on the editText to show the datePicker
        dateOfBirthET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // create the datePickerFragment
                AppCompatDialogFragment newFragment = new DatePickerFragment();
                // set the targetFragment to receive the results, specifying the request code
                newFragment.setTargetFragment(MedicineDetailsFragment.this, REQUEST_CODE);
                // show the datePicker
                newFragment.show(fm, "datePicker");
            }
        });


        timeOfBirthET.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                AppCompatDialogFragment newFragment1 = new TimePickerFragment();

                newFragment1.setTargetFragment(MedicineDetailsFragment.this, REQUEST_CODE1);

                newFragment1.show(fm, "timePicker");

            }

        });

        Button button = (Button) view.findViewById(R.id.add_button);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                if(!(selectedDate.matches("") || selectedTime.matches(""))) {
                    db = medicineSQLiteOpenHelper.getWritableDatabase();
                    MedicineSQLiteOpenHelper.insertSelectedMedicine(db, nameText, selectedDate, selectedTime);

                    Toast.makeText(getActivity(), "Medicine Added", Toast.LENGTH_SHORT).show();

                }

                else {
                    Toast.makeText(getActivity(), "Enter Time and Date", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    public void onSaveInstanceState(Bundle outState) {
        outState.putLong("medicine_id", medicineID);
    }

    public void setMedicineID(long medicineID) {
        this.medicineID = medicineID;
    }

//    public void showTimePickerDialog(View v) {
//        DialogFragment newFragment = new TimePickerFragment();
//        newFragment.show(getFragmentManager(), "timePicker");  }
//    public void showDatePickerDialog(View v) {
//        DialogFragment newFragment = new DatePickerFragment();
//        newFragment.setTargetFragment(MedicineDetailsFragment.this, REQUEST_CODE);
//        newFragment.show(getFragmentManager(), "datePicker"); }
//    public void setDateValue(String dateFormatted){
//        View v = getView();
//        setDate = dateFormatted;
//        TextView textView = v.findViewById(R.id.dateText);
//        textView.setText(setDate); }
//    public void setTimeValue(String timeFormatted){
//        View v = getView();
//        setTime = timeFormatted;
//        TextView textView = v.findViewById(R.id.timeText);
//        textView.setText(setTime); }
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        // check for the results
//        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
//            // get date from string
//            setDateValue(data.getStringExtra("selectedDate")); } }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // check for the results
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            // get date from string

            selectedDate = data.getStringExtra("selectedDate");
            // set the value of the editText
//            dateOfBirthET.setText(selectedDate);
            dateTextField.setText(selectedDate);

        }

        else if (requestCode == REQUEST_CODE1 && resultCode == Activity.RESULT_OK){
            selectedTime = data.getStringExtra("selectedTime");

            timeTextField.setText(selectedTime);
        }
    }


//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }



    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


}