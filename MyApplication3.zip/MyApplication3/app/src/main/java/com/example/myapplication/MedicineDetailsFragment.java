package com.example.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class MedicineDetailsFragment extends Fragment {
    private long medicineID;

    @Override
    public void onStart() {
        super.onStart();
        View view = getView();
        if(view != null){
            ImageView imageViewItemImage = view.findViewById(R.id.imageViewItemImage);
            TextView textViewName = view.findViewById(R.id.textViewName);
            TextView textViewDescription = view.findViewById(R.id.textViewDescription);

            MedicineSQLiteOpenHelper medicineSQLiteOpenHelper = new MedicineSQLiteOpenHelper(this.getContext());
            SQLiteDatabase db = medicineSQLiteOpenHelper.getReadableDatabase();
            Cursor cursor = db.query(
                    "MEDICINE",
                    new String[]{"_id", "NAME"},
                    "_id = ?",
                    new String[]{String.valueOf(medicineID)},
                    null,
                    null,
                    null);
        }
//        CODE HERE

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_medicine_details, container, false);
    }

    public void setMedicineID(long medicineID){
        this.medicineID = medicineID;
    }
}