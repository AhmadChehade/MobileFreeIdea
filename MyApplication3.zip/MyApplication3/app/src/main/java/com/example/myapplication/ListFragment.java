package com.example.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ListFragment extends androidx.fragment.app.ListFragment {
    private MedicineListListener medicineListListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        MedicineSQLiteOpenHelper db = new MedicineSQLiteOpenHelper(this.getContext());
        Cursor cursor = db.getMedicines();
        String medicines[] = new String[cursor.getCount()];
        int i=0;
        while(cursor.moveToNext()){
            medicines[i] = cursor.getString(1);
            i++;
        }
//        for (int i=0;i<cursor.getCount();i++){
//            cursor.moveToNext();
//            medicines[i] = cursor.getString(1);
//        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(inflater.getContext(),
                android.R.layout.simple_list_item_1, medicines);
        setListAdapter(arrayAdapter);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.medicineListListener = (MedicineListListener) context;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        if(medicineListListener != null){
            medicineListListener.itemClicked(id);
        }
    }

    interface MedicineListListener{
        void itemClicked(long id);
    }

}