package com.example.myapplication;


import android.app.ListActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MedicineActivity extends AppCompatActivity implements ListFragment.MedicineListListener {


    @Override
    public void itemClicked(long id) {
        View fragContainer = findViewById(R.id.frag_container);
        if(fragContainer != null){
            MedicineDetailsFragment medicineDetailsFragment = new MedicineDetailsFragment();
            medicineDetailsFragment.setMedicineID(id);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frag_container,medicineDetailsFragment);
            ft.addToBackStack(null);
            ft.commit();
        } else {
            Intent intent = new Intent(this, DisplayActivity.class);
            intent.putExtra(DisplayActivity.EXTRA_MEDICINE_ID,id);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}