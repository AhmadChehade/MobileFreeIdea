package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AddedMedicineActivity extends AppCompatActivity {

    SQLiteOpenHelper sqLiteOpenHelper;
    SQLiteDatabase db;
    EditText toRemove;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_added_medicine);

        linearLayout = (LinearLayout) findViewById(R.id.historyContainer);

        refreshLayout();

    }

    public void onClickRemove(View view) {

        toRemove = findViewById(R.id.remove_Edit);
        String idString = toRemove.getText().toString();

        if (!idString.matches("")) {
            int removeID = Integer.parseInt(idString);

            db = sqLiteOpenHelper.getReadableDatabase();
            int jack = db.delete("SELECTED_MEDICINE", "_id" + "='" + removeID + "' ;", null);

            if (jack == 1) {
                Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
            } else if (jack == 0) {
                Toast.makeText(this, "Item Deleted or Unavailable", Toast.LENGTH_SHORT).show();
            }

            refreshLayout();

        }

        else{
            Toast.makeText(this, "Error: Enter Remove ID", Toast.LENGTH_SHORT).show();
        }


    }

    public void refreshLayout(){

        if(((LinearLayout) linearLayout).getChildCount() > 0)
            ((LinearLayout) linearLayout).removeAllViews();

        try {
            sqLiteOpenHelper = new MedicineSQLiteOpenHelper(this);
            db = sqLiteOpenHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("select * from " + "SELECTED_MEDICINE", null);

            if (cursor.moveToFirst()) {
                while (!cursor.isAfterLast()) {
                    int id = cursor.getInt(cursor.getColumnIndex("_id"));
                    String medicine = cursor.getString(cursor.getColumnIndex("NAME"));
                    String date = cursor.getString(cursor.getColumnIndex("REMINDER_DATE"));
                    String time = cursor.getString(cursor.getColumnIndex("REMINDER_TIME"));
                    String output = "MedicineID: " + id + "\t\tName: " + medicine + "\t\t" + "Time: " + time + "\t\t - Date: " + date;
                    TextView textView = new TextView(this);
                    textView.setTextColor(Color.parseColor("#000000"));
                    textView.setText(output);
                    linearLayout.addView(textView);
                    cursor.moveToNext();
                }
            }

            db.close();
            cursor.close();

        }
        catch (Exception e){
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }

//    Cursor cursor =  this.db.rawQuery("select * from " + "SELECTED_MEDICINE" + " where " + "_id" + "='" + removeID + "'" , null);




}

