package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    SQLiteOpenHelper sqLiteOpenHelper;
    SQLiteDatabase db;
    long value;
    String upcomingName;
    Date smallestDate;
    TextView numberText;
    TextView upcomingText;
    Date df;
    Date df1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.new_toolbar);
        setSupportActionBar(toolbar);

        numberText = findViewById(R.id.medicationsTextView);
        upcomingText = findViewById(R.id.upComingMedication);




    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                Intent intent = new Intent(this, MedicineActivity.class);
                startActivity(intent);

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    public void onCheckMedicine(View view) {

        Intent intent = new Intent(this, AddedMedicineActivity.class);
        startActivity(intent);

    }

    @Override
    protected void onResume() {
        super.onResume();
        setValues();

        Toast.makeText(this, String.valueOf(value), Toast.LENGTH_SHORT).show();

        if(smallestDate != null){
            if(df.compareTo(smallestDate) == 0) {
                Intent intent = new Intent(MainActivity.this, BroadcastManager.class);
                intent.putExtra(BroadcastManager.EXTRA_MESSAGE, "Hi bitch");
                startService(intent);
            }
        }
    }





    public void setValues() {
        try {
            sqLiteOpenHelper = new MedicineSQLiteOpenHelper(this);
            db = sqLiteOpenHelper.getReadableDatabase();
            value = DatabaseUtils.queryNumEntries(db, "SELECTED_MEDICINE");

            Date c = Calendar.getInstance().getTime();
            System.out.println("Current time => " + c);
//            SimpleDateFormat currentDate = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
//            SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault());

            Cursor cursor = db.rawQuery("select * from " + "SELECTED_MEDICINE", null);

            String [] dateArray = new String[(int) value];
            String [] nameArray = new String[(int) value];

            if(cursor.getCount() > 0) {
                if (cursor.moveToFirst()) {
                    int i = 0;
                    while (!cursor.isAfterLast()) {
                        String medicine = cursor.getString(cursor.getColumnIndex("NAME"));
                        String date = cursor.getString(cursor.getColumnIndex("REMINDER_DATE"));
                        String time = cursor.getString(cursor.getColumnIndex("REMINDER_TIME"));

                        String fullDate = date + " " + time;

                        dateArray[i] = fullDate;
                        nameArray[i] = medicine;

//                        Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(date);
//                        Date time1=new SimpleDateFormat("hh:mm").parse(time);

                        i++;
                        cursor.moveToNext();
                    }
                }

                String smallest = dateArray[0];
                upcomingName = nameArray[0];
                smallestDate = new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(smallest);
                for (int j = 1; j < dateArray.length; j++) {
                    Date compareDate = new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(dateArray[j]);
                    if (compareDate.compareTo(smallestDate) < 0) {
                        smallestDate = compareDate;
                        upcomingName = nameArray[j];
                    }


                }


                String date1 = new SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.getDefault()).format(new Date());

                df = new SimpleDateFormat("MM/dd/yyyy HH:mm").parse(date1);
                numberText.setText(String.valueOf(value));
                upcomingText.setText(upcomingName + " at " + smallestDate.toString());

                if(df.compareTo(smallestDate) == 0) {
                    Intent intent = new Intent(MainActivity.this, BroadcastManager.class);
                    intent.putExtra(BroadcastManager.EXTRA_MESSAGE, "Hi bitch");
                    startService(intent);
                }

            }

            else {
                numberText.setText("0");
                upcomingText.setText("None");
            }

            Toast.makeText(this, smallestDate.toString(), Toast.LENGTH_SHORT).show();






        }
        catch (Exception e){
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}